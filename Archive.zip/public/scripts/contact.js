
document.getElementById('name').value = name;
   
document.getElementById('email').value = email;
     